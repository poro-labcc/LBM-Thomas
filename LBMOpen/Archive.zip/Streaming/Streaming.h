#ifndef STREAMING_H
#define STREAMING_H

#include "../SimStructure/LBMParams.h"
#include "../PostProcess/SimulationStats.h"

void Streaming(LBMParams &params, SimulationStats &stats);

#endif // STREAMING_H

